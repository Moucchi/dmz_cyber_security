#!/usr/bin/env bash
set -euo pipefail

# Fonction utilitaire pour configurer une IP si l'interface existe
set_ip() {
  local cidr="$1"
  local dev="$2"
  if ip link show dev "$dev" >/dev/null 2>&1; then
    ip addr replace "$cidr" dev "$dev"
  else
    echo "WARN: interface $dev introuvable, IP $cidr non appliquée" >&2
  fi
}

# Config réseau firewall (nécessite que le conteneur soit connecté aux bons réseaux)
set_ip 19.4.3.3/29  eth1
set_ip 19.4.3.11/29 eth2
set_ip 19.4.3.18/29 eth0

# Activer le routage IPv4
sysctl -w net.ipv4.ip_forward=1 >/dev/null
# Optionnel: le rendre persistant à chaque démarrage du conteneur (script rejoué)
echo 'net.ipv4.ip_forward=1' > /etc/sysctl.d/99-ip-forward.conf

exec "$@"