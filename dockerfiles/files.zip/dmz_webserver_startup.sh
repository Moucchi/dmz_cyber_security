#!/usr/bin/env bash
set -euo pipefail

# Config réseau dmz_webserver
ip addr replace 19.4.3.9/29 dev eth0
ip route replace default via 19.4.3.11 dev eth0

exec "$@"